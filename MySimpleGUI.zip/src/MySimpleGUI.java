import layout.Frame;

public class MySimpleGUI {

	public static void main(String[] args) {
		//����
		Frame.start();
	}
}
